<?php
include 'api/api_dashboard.php';
include 'includes/header.php';

$stmt = $db->prepare("SELECT message, timestamp FROM activity_logs ORDER BY timestamp DESC LIMIT 10");
$stmt->execute();
$recent_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="row mb-3 fade-in delay-1">
  <div class="col-12">
    <h1 class="mb-0" style="color: #2F4858;">
      <i class="fas fa-tachometer-alt me-2" style="color: #2AB7CA;"></i> Dashboard
    </h1>
    <hr>
  </div>
</div>
<div class="row g-3 mb-4 fade-in delay-2">
  <?php if (isAdmin()): ?>
    <div class="col-md-4">
      <div class="card text-white shadow rounded-4 border-0 " style="background-color: #004F80;">
        <div class="card-body d-flex align-items-center">
          <i class="fas fa-file-alt fa-2x me-3"style="color: #2AB7CA;"></i>
          <div>
            <h6 class="mb-0">Total Documents</h6>
            <h4>
              <span class="count-up" data-target="<?php echo $total_documents; ?>">0</span>
            </h4>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-white shadow rounded-4 border-0" style="background-color: #004F80;">
        <div class="card-body d-flex align-items-center">
          <i class="fas fa-database fa-2x me-3"style="color: #2AB7CA;"></i>
          <div>
            <h6 class="mb-0">Storage Used</h6>
            <h4>
                <span class="count-bytes" data-bytes="<?php echo $total_size; ?>">0 KB</span>
            </h4>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-white shadow rounded-4 border-0" style="background-color: #004F80;">
        <div class="card-body d-flex align-items-center">
          <i class="fas fa-folder-tree fa-2x me-3"style="color: #2AB7CA;"></i>
          <div>
            <h6 class="mb-0">Categories</h6>
            <h4>
              <span class="count-up" data-target="<?php echo count($categories); ?>">0</span>
            </h4>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
</div>
<script>
  function formatBytes(bytes) {
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    while (bytes >= 1024 && i < units.length - 1) {
      bytes /= 1024;
      i++;
    }
    return bytes.toFixed(1) + ' ' + units[i];
  }
  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".count-up").forEach(counter => {
      const target = +counter.getAttribute("data-target");
      let current = 0;
      const stepTime = Math.max(15, Math.floor(1500 / target));
      const update = () => {
        current++;
        counter.textContent = current;
        if (current < target) {
          setTimeout(update, stepTime);
        } else {
          counter.textContent = target.toLocaleString();
        }
      };
      update();
    });
    document.querySelectorAll(".count-bytes").forEach(counter => {
      const bytes = +counter.getAttribute("data-bytes");
      let current = 0;
      const steps = 100;
      const increment = bytes / steps;
      const stepTime = 15;
      const update = () => {
        current += increment;
        if (current < bytes) {
          counter.textContent = formatBytes(current);
          setTimeout(update, stepTime);
        } else {
          counter.textContent = formatBytes(bytes);
        }
      };
      update();
    });
  });
</script>
<div class="row g-2 fade-in delay-3">
  <link href="assets/css/custom.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="assets/js/weekly_uploads.js"></script>
   <?php if (isAdmin()): ?>
    <?php if (!empty($weekly_uploads) && array_sum($weekly_uploads) > 0): ?>
      <div class="col-md-8">
        <div class="card h-100 shadow rounded-4 border-0">
          <div class="card-header d-flex justify-content-between align-items-center bg-white border-bottom rounded-top-4">
            <h5 class="mb-0">
              <i class="fas fa-chart-line me-2" style="color: #004F80;"></i> Weekly Uploads
            </h5>
          </div>
          <div class="card-body">
            <canvas id="weeklyUploadsChart"
              height="250"
              data-labels='<?php echo json_encode(array_keys($weekly_uploads)); ?>'
              data-data='<?php echo json_encode(array_values($weekly_uploads)); ?>'>
            </canvas>
          </div>
        </div>
      </div>
    <?php else: ?>
      <div class="col-md-8">
        <?php include 'recent_documents_partial.php'; ?>
      </div>
    <?php endif; ?>
  <?php else: ?>
    <div class="col-md-8">
      <?php include 'recent_documents_partial.php'; ?>
    </div>
  <?php endif; ?>
  <div class="col-md-4 fade-in delay-2 ">
    <div class="card h-100 shadow rounded-4 border-0">
      <div class="card-header d-flex align-items-center bg-white border-bottom">
        <h5 class="mb-0">
          <i class="fas fa-bolt me-2" style="color: #2AB7CA;"></i> Quick Actions
        </h5>
      </div>
      <div class="card-body d-flex flex-column gap-2">
        <a href="documents/upload.php" class="btn rounded-pill" style ="background-color: #004F80; color: white;">
          <i class="fas fa-upload me-2"></i>Upload Document
        </a>
        <?php if (isAdmin()): ?>
        <a href="categories/manage.php" class="btn rounded-pill" style="background-color: #FFD166; color: #2F4858;">
          <i class="fas fa-layer-group me-2"></i>Manage Categories
        </a>
        <?php endif; ?>
        <a href="documents/browse.php" class="btn rounded-pill" style="background-color: #2F4858; color: white;">
          <i class="fas fa-folder me-2"></i>Browse Folders
        </a>
      </div>
    </div>
  </div>
  <?php if (isAdmin()): ?>
    <div class="card shadow rounded-4 border-0">
      <div class="card-header d-flex justify-content-between align-items-center bg-white border-bottom rounded-top-4">
        <div>
          <h5 class="mb-0">
            <i class="fas fa-folder-open me-2" style="color: #2AB7CA;"></i> All Documents
          </h5>
          <small class="text-muted">All your uploaded files in one place</small>
        </div>
        <a href="documents/search.php" class="btn btn-sm rounded-pill px-3" style="background-color: #2AB7CA; color: white; font-weight: 500;">View All</a>
      </div>
      <div class="card-body">
        <?php if (empty($recent_documents)): ?>
                <div class="text-center py-4">
                    <i class="fas fa-file-plus fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No documents uploaded yet</h5>
                    <p class="text-muted">Upload your documents.</p>
                    <a href="documents/browse.php" class="btn" style="background-color: #004F80; color: white;">
                        <i class="fas fa-folder-open me-2" style="color: white;"></i>Browse Documents
                    </a>
                </div>
                    <?php else: ?>
                        <table class="table table-hover align-middle mb-0">
                          <thead class="table-light">
                            <tr>
                              <th class="ps-3">Document</th>
                              <th>Category</th>
                              <th>Size</th>
                              <th>Date</th>
                              <th class="text-center">Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php foreach ($recent_documents as $doc): ?>
                              <tr>
                                <td>
                                  <i class="<?php echo getFileIcon(pathinfo($doc['filename'], PATHINFO_EXTENSION)); ?> me-2"></i>
                                  <?php echo htmlspecialchars($doc['title']); ?>
                                </td>
                                <td>
                                  <?php if ($doc['category_name']): ?>
                                    <span class="badge" style="background-color: <?php echo $doc['category_color']; ?>;">
                                      <?php echo htmlspecialchars($doc['category_name']); ?>
                                    </span>
                                  <?php else: ?>
                                    <span class="badge bg-secondary">Uncategorized</span>
                                  <?php endif; ?>
                                </td>
                                <td><?php echo formatFileSize($doc['file_size']); ?></td>
                                <td><?php echo date('M j, Y g:i A', strtotime($doc['created_at'])); ?></td>
                                <td class="text-center">
                                  <div class="dropdown">
                                    <button class="btn btn-light btn-sm rounded-circle" type="button" id="docActions<?= $doc['id'] ?>" data-bs-toggle="dropdown" aria-expanded="false" style="border: none;">
                                      <i class="fas fa-ellipsis-v" style="font-size: 1.2rem; color: #2F4858;"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="docActions<?= $doc['id'] ?>">
                                      <li><a class="dropdown-item" href="documents/preview.php?id=<?= $doc['id'] ?>"><i class="fas fa-eye me-2"></i> Preview</a></li>
                                      <li><a class="dropdown-item" href="documents/download.php?id=<?= $doc['id'] ?>"><i class="fas fa-download me-2"></i> Download</a></li>
                                      <li><a class="dropdown-item" href="documents/view.php?id=<?= $doc['id'] ?>"><i class="fas fa-info-circle me-2"></i> Details</a></li>
                                      <li><a class="dropdown-item" href="documents/share.php?id=<?= $doc['id'] ?>"><i class="fas fa-share me-2"></i> Share</a></li>
                                      <?php if ($doc['uploaded_by'] == $_SESSION['user_id'] || isAdmin()): ?>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item text-danger" href="documents/delete.php?id=<?= $doc['id'] ?>"><i class="fas fa-trash me-2"></i> Delete</a></li>
                                      <?php endif; ?>
                                    </ul>
                                  </div>
                                </td>
                              </tr>
                            <?php endforeach; ?>
                          </tbody>
                        </table>
                    <nav aria-label="Recent documents pagination" class="mt-3" style="background: transparent;">
                      <ul class="pagination justify-content-center mb-0">
                        <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                          <a class="page-link" href="?page=<?= $page - 1 ?>" tabindex="-1" aria-disabled="<?= ($page <= 1) ? 'true' : 'false' ?>">Previous</a>
                        </li>

                        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                          <li class="page-item <?= ($p == $page) ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $p ?>"><?= $p ?></a>
                          </li>
                        <?php endfor; ?>
                    
                        <li class="page-item <?= ($page >= $totalPages) ? 'disabled' : '' ?>">
                          <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
                        </li>
                      </ul>
                    </nav>
          <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>
  <div class="col-md-8 mt-2 fade-in delay-4">
    <div class="card shadow rounded-4 border-0">
      <div class="card-header d-flex justify-content-between align-items-center bg-white border-bottom">
        <div>
          <h5 class="mb-0">
            <i class="fas fa-users me-2" style="color: #2AB7CA;"></i> Documents Shared With Me
          </h5>
          <small class="text-muted">Files shared to you by other users</small>
        </div>
        <?php if (!empty($shared_documents)): ?>
          <span class="badge rounded-pill" style="background-color: #2AB7CA; color: white; font-weight: 500;">
            <?php echo count($shared_documents); ?> shared
          </span>
        <?php endif; ?>
      </div>
      <div class="card-body">
        <?php if (empty($shared_documents)): ?>
          <div class="text-center py-4">
            <i class="fas fa-share-alt fa-3x text-muted mb-3"></i>
            <h6 class="text-muted">No shared documents</h6>
            <p class="text-muted">Files that others send you will show up here.</p>
          </div>
        <?php else: ?>
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th class="ps-3">Document</th>
                  <th>Owner</th>
                  <th>Category</th>
                  <th>Permission</th>
                  <th>Size</th>
                  <th class="text-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($shared_documents as $doc): ?>
                  <tr>
                    <td>
                      <i class="<?php echo getFileIcon(pathinfo($doc['filename'], PATHINFO_EXTENSION)); ?> me-2"></i>
                      <?php echo htmlspecialchars($doc['title']); ?>
                    </td>
                    <td><?php echo htmlspecialchars($doc['owner_name']); ?></td>
                    <td>
                      <?php if ($doc['category_name']): ?>
                        <span class="badge" style="background-color: <?php echo $doc['category_color']; ?>;">
                          <?php echo htmlspecialchars($doc['category_name']); ?>
                        </span>
                      <?php else: ?>
                        <span class="badge bg-secondary">Uncategorized</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <span class="badge bg-<?php echo $doc['permission'] === 'download' ? 'success' : 'info'; ?>">
                        <?php echo $doc['permission'] === 'download' ? 'View & Download' : 'View Only'; ?>
                      </span>
                    </td>
                    <td><?php echo formatFileSize($doc['file_size']); ?></td>
                    <td class="text-center">
                      <div class="dropdown">
                        <button class="btn btn-light btn-sm rounded-circle" type="button" id="sharedDocActions<?= $doc['id'] ?>" data-bs-toggle="dropdown" aria-expanded="false" style="border: none;">
                          <i class="fas fa-ellipsis-v" style="font-size: 1.2rem; color: #2F4858;"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="sharedDocActions<?= $doc['id'] ?>">
                          <li><a class="dropdown-item" href="documents/preview.php?id=<?php echo $doc['id']; ?>"><i class="fas fa-eye me-2"></i> Preview</a></li>
                          <?php if ($doc['permission'] === 'download'): ?>
                            <li><a class="dropdown-item" href="documents/download.php?id=<?php echo $doc['id']; ?>"><i class="fas fa-download me-2"></i> Download</a></li>
                          <?php endif; ?>
                          <li><a class="dropdown-item" href="documents/view.php?id=<?php echo $doc['id']; ?>"><i class="fas fa-info-circle me-2"></i> Details</a></li>
                        </ul>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
        <?php endif; ?>
      </div>
    </div>
  </div>
    <div class="col-md-4 fade-in delay-3">
    <?php
      $display_limit = 5;
      $has_more_logs = count($recent_logs) > $display_limit;
      $display_logs = array_slice($recent_logs, 0, $display_limit);
    ?>
    <div class="card h-100 shadow rounded-4 border-0">
      <div class="card-header bg-white border-bottom">
        <h5 class="mb-0">
          <i class="fas fa-history me-2" style="color: #2AB7CA;"></i> Recent Activity
        </h5>
      </div>
      <div class="card-body">
        <?php if (empty($display_logs)): ?>
          <p class="text-muted">No activity logs available.</p>
        <?php else: ?>
          <ul class="list-unstyled small">
            <?php foreach ($display_logs as $log): ?>
              <li class="mb-2">
                <i class="fas fa-circle text-success me-2" style="font-size: 8px;"></i>
                <?php echo htmlspecialchars($log['message']); ?><br>
                <small class="text-muted"><?php echo date('M d, Y g:i A', strtotime($log['timestamp'])); ?></small>
              </li>
            <?php endforeach; ?>
          </ul>
          <?php if ($has_more_logs): ?>
            <div class="mt-2">
              <a href="logs/audit.php" class="btn btn-sm" style="background-color: #004F80; color: white;">View More</a>
            </div>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>