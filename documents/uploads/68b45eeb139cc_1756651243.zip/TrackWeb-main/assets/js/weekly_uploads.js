document.addEventListener("DOMContentLoaded", function () {
  const chartElement = document.getElementById('weeklyUploadsChart');

  if (chartElement) {
    const labels = JSON.parse(chartElement.dataset.labels || "[]");
    const data = JSON.parse(chartElement.dataset.data || "[]");

    new Chart(chartElement.getContext('2d'), {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Documents Uploaded',
          data: data,
          backgroundColor: 'rgba(0, 79, 128, 0.7)',
          borderColor: '#004F80',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: {
          duration: 4500,
          easing: 'easeOutBounce'
        },
        scales: {
          y: {
            beginAtZero: true,
            stepSize: 1
          }
        }
      }
    });
  }
});
