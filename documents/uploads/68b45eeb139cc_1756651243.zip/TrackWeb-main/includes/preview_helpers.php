<?php
require_once __DIR__ . '/../vendor/autoload.php';

function previewDocx($filePath) {
    if (!file_exists($filePath)) return 'File not found.';

    $html = '';
    try {
        $phpWord = \PhpOffice\PhpWord\IOFactory::load($filePath);
        foreach ($phpWord->getSections() as $section) {
            foreach ($section->getElements() as $element) {
                if (method_exists($element, 'getText')) {
                    $html .= htmlspecialchars($element->getText()) . "<br>";
                }
            }
        }
        
        $zip = new ZipArchive;
        $imgHtml = '';
        if ($zip->open($filePath) === TRUE) {
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $entryName = $zip->getNameIndex($i);
                if (preg_match('/^word\/media\/.+\.(jpg|jpeg|png|gif)$/i', $entryName)) {
                    $imageData = $zip->getFromIndex($i);
                    $base64 = base64_encode($imageData);
                    $mime = mime_content_type('data://application/octet-stream;base64,' . $base64);
                    $imgHtml .= '<img src="data:' . $mime . ';base64,' . $base64 . '" class="img-fluid mb-2" style="max-height: 200px;"><br>';
                }
            }
            $zip->close();
        }

        return "<div class='mb-3'><br><div style='white-space: pre-wrap;'>$html</div></div>
                <div><br>$imgHtml</div>";

    } catch (Exception $e) {
        return "Unable to preview DOCX: " . $e->getMessage();
    }
}


function previewXlsx($filePath) {
    if (!file_exists($filePath)) return 'File not found.';

    $html = '<table class="table table-bordered table-sm">';
    try {
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($filePath);
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray();

        $rowLimit = 20;
        foreach (array_slice($rows, 0, $rowLimit) as $row) {
            $html .= '<tr>';
            foreach ($row as $cell) {
                $html .= '<td>' . htmlspecialchars($cell) . '</td>';
            }
            $html .= '</tr>';
        }
        if (count($rows) > $rowLimit) {
            $html .= '<tr><td colspan="100%">... (Truncated)</td></tr>';
        }

    } catch (Exception $e) {
        return "Unable to preview XLSX: " . $e->getMessage();
    }
    return $html . '</table>';
}

function previewPptx($filePath) {
    // Only show text content from all slides
    if (!file_exists($filePath)) return 'File not found.';
    $zip = new ZipArchive;
    if ($zip->open($filePath) === true) {
        $output = '';
        $slideCount = 1;
        while (true) {
            $slideXml = $zip->getFromName("ppt/slides/slide" . $slideCount . ".xml");
            if ($slideXml === false) break;
            $xml = simplexml_load_string($slideXml);
            $xml->registerXPathNamespace('a', 'http://schemas.openxmlformats.org/drawingml/2006/main');
            $texts = $xml->xpath('//a:t');
            $slideText = implode(' ', array_map('strval', $texts));
            $output .= "<strong>Slide $slideCount:</strong><br>" . htmlspecialchars($slideText) . "<br><br>";
            $slideCount++;
        }
        $zip->close();
        return $output ?: 'No content found in slides.';
    }
    return 'Unable to open PowerPoint file.';
}

?>